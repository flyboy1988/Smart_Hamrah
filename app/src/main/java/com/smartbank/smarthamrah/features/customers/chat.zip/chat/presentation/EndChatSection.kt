package com.smartbank.smarthamrah.features.customers.chat.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartbank.smarthamrah.ui.theme.BrandHeaderBlue
import com.smartbank.smarthamrah.ui.theme.GrayText

@Composable
fun EndChatSection(
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    enabled: Boolean = true,
    onConfirmEndChat: () -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    Column(modifier = modifier) {
        OutlinedButton(
            onClick = { showDialog = true },
            enabled = enabled && !isLoading,
            shape = RoundedCornerShape(10.dp),
            // تنظیم رنگ بوردر به خاکستری و رنگ متن به خاکستری ملایم
            border = androidx.compose.foundation.BorderStroke(1.dp, androidx.compose.ui.graphics.Color.LightGray),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = GrayText // یا هر رنگ خاکستری که در تم دارید
            ),
            // کم کردن پدینگ داخلی برای جمع‌وجور شدن دکمه (مطابق اسکرین‌شات)
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(28.dp) // ارتفاع دکمه کمتر شد تا ظریف شود
        ) {
            Text(
                text = "خاتمه گفتگو",
                fontSize = 11.sp,  // سایز فونت کمی کوچک‌تر برای جا شدن دقیق
                fontWeight = FontWeight.Normal
            )
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = {
                    if (!isLoading) showDialog = false
                },
                shape = RoundedCornerShape(20.dp),
                containerColor = MaterialTheme.colorScheme.surface,
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "خاتمه گفتگو",
                            color = BrandHeaderBlue,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )

                        IconButton(
                            enabled = !isLoading,
                            onClick = { showDialog = false }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = null,
                                tint = BrandHeaderBlue
                            )
                        }
                    }
                },
                text = {
                    Column {
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "آیا گفتگو پایان یابد؟",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    showDialog = false
                                    onConfirmEndChat()
                                },
                                enabled = !isLoading,
                                modifier = Modifier.weight(1f).height(36.dp), // کوچکتر
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandHeaderBlue
                                )
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.height(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                } else {
                                    Text(
                                        text = "بله",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = { showDialog = false },
                                enabled = !isLoading,
                                modifier = Modifier.weight(1f).height(36.dp), // کوچکتر
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = BrandHeaderBlue
                                )
                            ) {
                                Text(
                                    text = "خیر",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {}
            )
        }
    }
}